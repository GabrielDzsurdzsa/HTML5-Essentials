﻿$(document).ready(function () { 
    
    /*Initialize accordion*/
    $("#info-accordion").accordion({ heightStyle: "content" });

})