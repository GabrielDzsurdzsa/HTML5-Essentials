﻿$(document).ready(function () {

    /*Show progress*/
    $(".progress").fadeOut("slow");
        
})