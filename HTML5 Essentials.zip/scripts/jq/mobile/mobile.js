﻿$(document).ready(function () {

    /*Toggle mobile menu*/
    $("mobile button").click(function () { $(this.parentNode.parentNode.children[2]).fadeToggle(); }); 
       
})